prompt Importing table etl.t_table...
--set feedback off
--set define off

alter table ETL.T_TABLE
  add constraint PK#T_TABLE primary key (TABLE_ID);

delete from etl.t_table where table_id in (180);
insert into etl.t_table (TABLE_ID, TABLE_NAME, SYS_CODE, ACTUAL_FLAG, OWNER)
values (180, 'V_CRM_EVENTS', '05', 1, 'STG_XML_CRM');


commit;

delete from etl.t_table_rule where rule_id in (393);
insert into etl.t_table_rule (RULE_ID, TABLE_ID, ACTUAL_FLAG, K_TYPE, K_TABLE_NAME, K_PK_FILED, K_RULE_TYPE)
values (393, 180, 1, 'PK', 'LNK_EVENTS', 'EVENTS_KEY', 1);

commit;
delete from etl.ref_rule_field where rule_id in (393);
insert into etl.ref_rule_field (RULE_ID, FIELD_NAME, ACTUAL_FLAG, K_FIELD_NAME)
values (393, 'CRM_CONTRACT_ID_CD,EVENT_DATE,LEASING_SUBJECT_NUM', 1, 'CRM_CONTRACT_ID_CD_1,DATE_1,LEASING_SUBJECT_NUM_1');

prompt Done.
